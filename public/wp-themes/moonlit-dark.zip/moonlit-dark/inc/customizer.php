<?php
/**
 * Add custom settings and controls to the WordPress Customizer
 */


//---------------------Code to add the Upgrade to Pro button in the Customizer----------

function moonlit_dark_customize_register_btn( $wp_customize ) {
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

    get_template_part('inc/customizer-button/upsell-section');


    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'blogname', array(
            'selector'        => '.site-title a',
            'render_callback' => 'moonlit_dark_customize_partial_blogname',
        ) );
        $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
            'selector'        => '.site-description',
            'render_callback' => 'moonlit_dark_customize_partial_blogdescription',
        ) );
    }

    $wp_customize->register_section_type( 'moonlit_dark_Customize_Upsell_Section' );

    // Register section.
    $wp_customize->add_section(
        new moonlit_dark_Customize_Upsell_Section(
            $wp_customize,
            'theme_upsell',
            array(
                'title'    => esc_html__( 'Moonlit Pro', 'moonlit-dark' ),
                'pro_text' => esc_html__( 'Upgrade To Pro', 'moonlit-dark' ),
                'pro_url'  => 'https://cawpthemes.com/moonlit-dark-blog-theme/',
                'priority' => 1,
            )
        )
    );
}
add_action( 'customize_register', 'moonlit_dark_customize_register_btn' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function moonlit_dark_customize_partial_blogname() {
    bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function moonlit_dark_customize_partial_blogdescription() {
    bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function moonlit_dark_customize_preview_js() {
    wp_enqueue_script( 'moonlit-dark-customizer', get_template_directory_uri() . '/inc/customizer-button/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'moonlit_dark_customize_preview_js' );

/**
 * Customizer control scripts and styles.
 *
 * @since 1.0.0
 */
function moonlit_dark_customizer_control_scripts() {

    wp_enqueue_style( 'moonlit-dark-customize-controls', get_template_directory_uri() . '/inc/customizer-button/customize-controls.css', '', '1.0.0' );

    wp_enqueue_script( 'moonlit-dark-customize-controls', get_template_directory_uri() . '/inc/customizer-button/customize-controls.js', array( 'customize-controls' ), '1.0.0', true );
}
add_action( 'customize_controls_enqueue_scripts', 'moonlit_dark_customizer_control_scripts', 0 );


//---------------------Code to add the Upgrade to Pro button in the Customizer End----------


//------------------Theme Information--------------------

function moonlit_dark_customize_register( $wp_customize ) {



      // Add a custom setting for the Site Identity color
  $wp_customize->add_setting( 'moonlit_dark_site_identity_color', array(
    'default' => '#fff',
    'sanitize_callback' => 'sanitize_hex_color',
  ) );

  // Add a custom control for the primary color
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'moonlit_dark_site_identity_color', array(
    'label' => __( 'Site Identity Color', 'moonlit-dark' ),
    'section' => 'title_tagline',
    'settings' => 'moonlit_dark_site_identity_color',
  ) ) );


  // Add a custom setting for the Site Identity color
  $wp_customize->add_setting( 'moonlit_dark_site_identity_tagline_color', array(
    'default' => '#fff',
    'sanitize_callback' => 'sanitize_hex_color',
  ) );

  // Add a custom control for the primary color
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'moonlit_dark_site_identity_tagline_color', array(
    'label' => __( 'Tagline Color', 'moonlit-dark' ),
    'section' => 'title_tagline',
    'settings' => 'moonlit_dark_site_identity_tagline_color',
  ) ) );

//------------------Site Identity Ends---------------------


  
  // Add a custom setting for the primary color
  $wp_customize->add_setting( 'moonlit_dark_primary_color', array(
    'default' => '#dd3333',
    'sanitize_callback' => 'sanitize_hex_color',
  ) );

  // Add a custom control for the primary color
  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'moonlit_dark_primary_color', array(
    'label' => __( 'Primary Color', 'moonlit-dark' ),
    'section' => 'colors',
    'settings' => 'moonlit_dark_primary_color',
  ) ) );

  //-----------------------------------Home Front Page-------------------------------

  $wp_customize->add_panel( 'moonlit_dark_panel', array(
    'title'    => __( 'Front Page Settings', 'moonlit-dark' ),
    'priority' => 6,
  ) );


  //-------------------------------------Banner Iamge Section--------------

      $wp_customize->add_section( 'moonlit_dark_section_banner', array(
        'title'    => __( 'First Banner Image', 'moonlit-dark' ),
        'priority' => 8,
        'panel'    => 'moonlit_dark_panel',
    ) );


  //-----------------Enable Option banner-------------

  $wp_customize->add_setting('moonlit_dark_section_banner',array(
      'default' => 'Enable',
      'sanitize_callback' => 'moonlit_dark_sanitize_choices'
  ));
  $wp_customize->add_control('moonlit_dark_section_banner',array(
        'type' => 'radio',
        'label' => __('Do you want this section', 'moonlit-dark'),
        'section' => 'moonlit_dark_section_banner',
        'choices' => array(
            'Enable' => __('Enable', 'moonlit-dark'),
            'Disable' => __('Disable', 'moonlit-dark')
  )));

  $wp_customize->add_setting('moonlit_dark_section_bannerimage_section',array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));
  $wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize,'moonlit_dark_section_bannerimage_section',array(
    'label' => __('Section Background Image','moonlit-dark'),
    'description' => __('Dimention 1600 * 400','moonlit-dark'),
    'section' => 'moonlit_dark_section_banner',
    'settings' => 'moonlit_dark_section_bannerimage_section'
  )));

    $wp_customize->add_setting('moonlit_dark_section_bannerimage_section_title',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    )
  );
  $wp_customize->add_control('moonlit_dark_section_bannerimage_section_title',array(
      'label' => __('Banner Title','moonlit-dark'),
      'section' => 'moonlit_dark_section_banner',
      'setting' => 'moonlit_dark_section_bannerimage_section_title',
      'type'    => 'text'
    )
  ); 

      $wp_customize->add_setting('moonlit_dark_section_bannerimage_section_text',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    )
  );
  $wp_customize->add_control('moonlit_dark_section_bannerimage_section_text',array(
      'label' => __('Banner Text','moonlit-dark'),
      'section' => 'moonlit_dark_section_banner',
      'setting' => 'moonlit_dark_section_bannerimage_section_text',
      'type'    => 'text'
    )
  ); 


  //-----------------------------------------------------------------Section One (Featured Post)------------------------------------------

  $wp_customize->add_section( 'moonlit_dark_section1', array(
        'title'    => __( 'Latest Post', 'moonlit-dark' ),
        'priority' => 10,
        'panel'    => 'moonlit_dark_panel',
    ) );


  //-----------------Enable Option Section One-------------

  $wp_customize->add_setting('moonlit_dark_section1_enable',array(
      'default' => 'Enable',
      'sanitize_callback' => 'moonlit_dark_sanitize_choices'
  ));
  $wp_customize->add_control('moonlit_dark_section1_enable',array(
        'type' => 'radio',
        'label' => __('Do you want this section', 'moonlit-dark'),
        'section' => 'moonlit_dark_section1',
        'choices' => array(
            'Enable' => __('Enable', 'moonlit-dark'),
            'Disable' => __('Disable', 'moonlit-dark')
  )));

    //--------------Section One Title-----------------------

    $wp_customize->add_setting('moonlit_dark_section1_title',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    )
  );
  $wp_customize->add_control('moonlit_dark_section1_title',array(
      'label' => __('Section Title','moonlit-dark'),
      'section' => 'moonlit_dark_section1',
      'setting' => 'moonlit_dark_section1_title',
      'type'    => 'text'
    )
  ); 

  //-----------Category------------

  $categories = get_categories();
  $cats = array();
  $i = 0;
  foreach($categories as $category){
    if($i==0){
      $default = $category->name;
      $i++;
    }
    $cats[$category->name] = $category->name;
  }

  $wp_customize->add_setting('moonlit_dark_section1_category',array(
  'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('moonlit_dark_section1_category',array(
    'type'    => 'select',
    'choices' => $cats,
    'label' => __('Select Category to Display Post','moonlit-dark'),
    'section' => 'moonlit_dark_section1',
    'sanitize_callback' => 'sanitize_text_field',
  ));



    $wp_customize->add_setting('moonlit_dark_section1_category_number_of_posts_setting',array(
    'default' => '6',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('moonlit_dark_section1_category_number_of_posts_setting',array(
    'label' => __('Number of Posts','moonlit-dark'),
    'section' => 'moonlit_dark_section1',
    'setting' => 'moonlit_dark_section1_category_number_of_posts_setting',
    'type'    => 'number'
  )); 


//------------------------Blog Page Settings--------------------------


  $wp_customize->add_section( 'moonlit_dark_blogpage_settings', array(
        'title'    => __( 'Blog Page Settings', 'moonlit-dark' ),
        'priority' => 10,
        'panel'    => 'moonlit_dark_panel',
    ) );

    //--------------Section One Title-----------------------

    $wp_customize->add_setting('moonlit_dark_blogpage_title',array(
      'default' => '',
      'sanitize_callback' => 'sanitize_text_field'
    )
  );
  $wp_customize->add_control('moonlit_dark_blogpage_title',array(
      'label' => __('Blog Page Title','moonlit-dark'),
      'section' => 'moonlit_dark_blogpage_settings',
      'setting' => 'moonlit_dark_blogpage_title',
      'type'    => 'text'
    )
  ); 

  //-----------Category------------

  $categories = get_categories();
  $cats = array();
  $i = 0;
  foreach($categories as $category){
    if($i==0){
      $default = $category->name;
      $i++;
    }
    $cats[$category->name] = $category->name;
  }

  $wp_customize->add_setting('moonlit_dark_blogpage_category',array(
  'sanitize_callback' => 'sanitize_text_field',
  ));
  $wp_customize->add_control('moonlit_dark_blogpage_category',array(
    'type'    => 'select',
    'choices' => $cats,
    'label' => __('Select Category to Display Post on Blog Page','moonlit-dark'),
    'section' => 'moonlit_dark_blogpage_settings',
    'sanitize_callback' => 'sanitize_text_field',
  ));



    $wp_customize->add_setting('moonlit_darkblog_page_category_number_of_posts_setting',array(
    'default' => '18',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('moonlit_darkblog_page_category_number_of_posts_setting',array(
    'label' => __('Number of Posts','moonlit-dark'),
    'section' => 'moonlit_dark_blogpage_settings',
    'setting' => 'moonlit_darkblog_page_category_number_of_posts_setting',
    'type'    => 'number'
  )); 


  //-------------------------Footer Settings------------------------------


    $wp_customize->add_section( 'moonlit_dark_footer', array(
        'title'    => __( 'Footer Settings', 'moonlit-dark' ),
        'priority' => 10,
        'panel'    => 'moonlit_dark_panel',
    ) );


  // Add a custom setting for the footer text
  $wp_customize->add_setting( 'moonlit_dark_footer_text', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ) );

  // Add a custom control for the footer text
  $wp_customize->add_control( 'moonlit_dark_footer_text', array(
    'label' => __( 'Footer Text', 'moonlit-dark' ),
    'section' => 'moonlit_dark_footer',
    'type' => 'text',
  ) );


 //-------------------404 Page-----------

  $wp_customize->add_section( 'moonlit_dark_404page', array(
    'title'    => __( '404 Page Settings', 'moonlit-dark' ),
    'priority' => 12,
    'panel'    => 'moonlit_dark_panel',
    ) );


  // Add a custom setting for the footer text
  $wp_customize->add_setting( 'moonlit_dark_404page_title', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ) );

  // Add a custom control for the footer text
  $wp_customize->add_control( 'moonlit_dark_404page_title', array(
    'label' => __( 'Page Not Found Title', 'moonlit-dark' ),
    'section' => 'moonlit_dark_404page',
    'type' => 'text',
  ) );

  // Add a custom setting for the footer text
  $wp_customize->add_setting( 'moonlit_dark_404page_text', array(
    'default' => '',
    'sanitize_callback' => 'sanitize_text_field',
  ) );

  // Add a custom control for the footer text
  $wp_customize->add_control( 'moonlit_dark_404page_text', array(
    'label' => __( 'Page Not Found Text', 'moonlit-dark' ),
    'section' => 'moonlit_dark_404page',
    'type' => 'text',
  ) );

//--------------------------------------General Settings------------------------------------------

  $wp_customize->add_section( 'moonlit_dark_general', array(
        'title'    => __( 'General Settings', 'moonlit-dark' ),
        'panel'    => 'moonlit_dark_panel',
    ) );

    $wp_customize->add_setting( 'moonlit_dark_post_meta_toggle_switch_control', array(
        'default'   => true,
        'sanitize_callback' => 'sanitize_text_field', // Use a suitable sanitization function based on your needs
        'transport' => 'refresh', // or 'postMessage' for instant preview without page refresh
    ) );

    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'moonlit_dark_post_meta_toggle_switch_control', array(
        'label'    => __( 'Display Time/Author', 'moonlit-dark' ),
        'section'  => 'moonlit_dark_general',
        'settings' => 'moonlit_dark_post_meta_toggle_switch_control',
        'type'     => 'checkbox',
    ) ) );

    $wp_customize->add_setting( 'moonlit_dark_post_readmore_toggle_switch_control', array(
        'default'   => true,
        'sanitize_callback' => 'sanitize_text_field', // Use a suitable sanitization function based on your needs
        'transport' => 'refresh', // or 'postMessage' for instant preview without page refresh
    ) );

    $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'moonlit_dark_post_readmore_toggle_switch_control', array(
        'label'    => __( 'Display Readmore Link', 'moonlit-dark' ),
        'section'  => 'moonlit_dark_general',
        'settings' => 'moonlit_dark_post_readmore_toggle_switch_control',
        'type'     => 'checkbox',
    ) ) );
    
}
add_action( 'customize_register', 'moonlit_dark_customize_register' );




