<div id="sidebar" class="widget-area" role="complementary">
    <?php dynamic_sidebar( 'primary-sidebar' ); ?>
</div><!-- #secondary -->


