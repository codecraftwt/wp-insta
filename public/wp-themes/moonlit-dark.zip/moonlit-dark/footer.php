<?php
/**
 * The template for displaying the footer.
 *
 * @package moonlit-dark
 */
?>
	<div class="Main-footer">
		<?php get_template_part( 'template-parts/footer/footer-file' ); ?>
	</div>
	<div class="clearfix"></div>
	<?php wp_footer(); ?>
	</body>
</html>