<?php
/**
 * Theme Section 1
 *
 * @package Moonlit Dark
 */

// All function code and function definitions go here...

$moonlit_dark_section_one = get_theme_mod('moonlit_dark_section_banner');
if ('Disable' === $moonlit_dark_section_one) {
    return;
}
?>

<section id="banner-section-first">
    <div class="main-banner-main">
        <?php 
        $banner_image = get_theme_mod('moonlit_dark_section_bannerimage_section');
        if (!empty($banner_image)) { ?>
            <img src="<?php echo esc_url($banner_image); ?>" alt="<?php esc_attr_e('Banner Image', 'moonlit-dark'); ?>">
        <?php } ?>
        
        <?php 
        $banner_title = get_theme_mod('moonlit_dark_section_bannerimage_section_title');
        if (!empty($banner_title)) { ?>
            <div class="text-box">
                <h2><?php echo esc_html($banner_title); ?></h2>
                <p><?php echo esc_html(get_theme_mod('moonlit_dark_section_bannerimage_section_text')); ?></p>
            </div>
        <?php } ?>
    </div>
</section>
